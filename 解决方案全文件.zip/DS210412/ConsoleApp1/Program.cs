﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 此控制台项目是为了方便测试wpf项目

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //获取当前路径
            string title = "UserInfo";
            string url = Directory.GetCurrentDirectory();
            url = url.Replace("bin\\Debug", "");
            string txtDir = url +"res\\" + title + ".txt";

            List<User.User> UserList = new List<User.User>();

            //读取文件
            if (File.Exists(txtDir))
            {
                StreamReader streamReader = new StreamReader(txtDir);
                while (streamReader.Peek() != -1)
                {
                    //读取文件中的一行字符
                    string str = streamReader.ReadLine();
                    string[] i = str.Split(' ');
                    User.User u = new User.User(i[0], i[1], int.Parse(i[2]), i[3]);
                    UserList.Add(u);

                }
                streamReader.Close();

            }
            else
            {
                Console.WriteLine(txtDir + " 文件不存在！");
            }
        }
    }
}
